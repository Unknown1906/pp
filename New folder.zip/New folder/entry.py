import tkinter as tk

def update_label():
    text = entry.get()  # Get text from entry
    label.config(text=text)  # Update label text

# Create the main window
root = tk.Tk()
root.title("Text")

# Create entry widget
entry = tk.Entry(root)
entry.pack(pady=10)

# Create button to update label
button = tk.Button(root, text="Copy Text", command=update_label)
button.pack(pady=10)

# Create label widget
label = tk.Label(root, text="Text is displayed here")
label.pack(pady=10)



# Run the main event loop
root.mainloop()