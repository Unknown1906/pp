import tkinter

# Writing to myLine.txt
with open('myLine.txt', 'w') as file:
    lines = ["Line 1\n", "Line 2\n", "Line 3\n", "Line 4\n", "Line 5\n", "Line 6\n", "Line 7\n", "Line 8\n", "Line 9\n", "Line 10\n"]
    file.writelines(lines)

# Reading the first 5 lines
print("First 5 lines of myLine.txt:")
with open('myLine.txt', 'r') as file:
    for i in range(5):
        print(file.readline().strip())

# Reading the last 5 lines
print("\nLast 5 lines of myLine.txt:")
with open('myLine.txt', 'r') as file:
    lines = file.readlines()
    for line in lines[-5:]:
        print(line.strip())
