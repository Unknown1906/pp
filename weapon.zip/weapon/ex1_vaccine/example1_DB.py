import mysql.connector

# Establish database connection
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password=""
)

mycursor = mydb.cursor()

# Create database if it does not exist
mycursor.execute("CREATE DATABASE IF NOT EXISTS vacciendb")

# Connect to the new database
dataBase = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="vacciendb"
)

# Create a cursor object using the cursor() method
cursorObj = dataBase.cursor()

# Create table if it does not exist
vaccine = """
CREATE TABLE IF NOT EXISTS listCitizen (
    icnumber VARCHAR(20) NOT NULL,
    name VARCHAR(100),
    age VARCHAR(3),
    citizen VARCHAR(3),
    Diabetes VARCHAR(30),
    Hyper VARCHAR(30),
    Heart VARCHAR(30),
    ageStatus VARCHAR(30),
    vacStatus VARCHAR(50),
    PRIMARY KEY (icnumber)
)
"""
cursorObj.execute(vaccine)
dataBase.commit()
dataBase.close()

class connVacDB:
    def __init__(self):
        print("...Successful connection to database...")
        self.connDB = mysql.connector.connect(host="localhost", user="root", password="")
        self.conn = mysql.connector.connect(host="localhost", user="root", password="", database="vaccine")
        self.cur = self.conn.cursor()
        self.conn.commit()
