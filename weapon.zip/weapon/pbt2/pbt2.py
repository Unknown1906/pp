import tkinter as tk
from tkinter import messagebox
import mysql.connector


def insert_data():

    name = name_entry.get()
    matric_number = matric_number_entry.get()
    program = program_var.get()
    gender = gender_var.get()
    telephone = telephone_entry.get()
    email = email_entry.get()
    theme = theme_var.get()
    

    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="pp_university"
        )
        cursor = conn.cursor()
        
        query = "INSERT INTO graduates (name, matric_number, program, gender, telephone, email, theme) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        data = (name, matric_number, program, gender, telephone, email, theme)
        cursor.execute(query, data)
        
        # Commit changes and close connection
        conn.commit()
        conn.close()
        
        # Display confirmation message
        messagebox.showinfo("Success", "Data inserted successfully!")
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"Error inserting data: {err}")

# Create main window
root = tk.Tk()
root.title("PP University Voting Application")


name_label = tk.Label(root, text="Name:")
name_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
name_entry = tk.Entry(root)
name_entry.grid(row=0, column=1, padx=10, pady=5)

matric_number_label = tk.Label(root, text="Matric Number:")
matric_number_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
matric_number_entry = tk.Entry(root)
matric_number_entry.grid(row=1, column=1, padx=10, pady=5)

program_label = tk.Label(root, text="Program:")
program_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")
program_var = tk.StringVar(root)
program_var.set("Select Program")
program_dropdown = tk.OptionMenu(root, program_var, "Program A", "Program B", "Program C")
program_dropdown.grid(row=2, column=1, padx=10, pady=5)

gender_label = tk.Label(root, text="Gender:")
gender_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")
gender_var = tk.StringVar(root)
gender_var.set("Male")
gender_male = tk.Radiobutton(root, text="Male", variable=gender_var, value="Male")
gender_male.grid(row=3, column=1, padx=10, pady=5, sticky="w")
gender_female = tk.Radiobutton(root, text="Female", variable=gender_var, value="Female")
gender_female.grid(row=3, column=1, padx=10, pady=5, sticky="e")

telephone_label = tk.Label(root, text="Telephone:")
telephone_label.grid(row=4, column=0, padx=10, pady=5, sticky="w")
telephone_entry = tk.Entry(root)
telephone_entry.grid(row=4, column=1, padx=10, pady=5)

email_label = tk.Label(root, text="Email:")
email_label.grid(row=5, column=0, padx=10, pady=5, sticky="w")
email_entry = tk.Entry(root)
email_entry.grid(row=5, column=1, padx=10, pady=5)

theme_label = tk.Label(root, text="Theme:")
theme_label.grid(row=6, column=0, padx=10, pady=5, sticky="w")
theme_var = tk.StringVar(root)
theme_var.set("Select Theme")
theme_dropdown = tk.OptionMenu(root, theme_var, "Theme A", "Theme B", "Theme C")
theme_dropdown.grid(row=6, column=1, padx=10, pady=5)

# Create and place submit button
submit_button = tk.Button(root, text="Submit", command=insert_data)
submit_button.grid(row=7, column=0, columnspan=2, padx=10, pady=10)

# Run the application
root.mainloop()