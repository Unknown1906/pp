class Time:
    def __init__(self, seconds):
        self.seconds = seconds

    def convert_to_minutes(self):
        minutes = self.seconds // 60
        remaining_seconds = self.seconds % 60
        return f"{minutes}:{remaining_seconds:02d}"

    def convert_to_hours(self):
        hours = self.seconds // 3600
        remaining_seconds = self.seconds % 3600
        minutes = remaining_seconds // 60
        seconds = remaining_seconds % 60
        return f"{hours}:{minutes:02d}:{seconds:02d}"

# Example usage:
time_instance = Time(3680)
print("Convert to Minutes")
print(f"{time_instance.seconds} seconds = {time_instance.convert_to_minutes()} minutes")

print("Convert to Hours")
print(f"{time_instance.seconds} seconds = {time_instance.convert_to_hours()} hour")
