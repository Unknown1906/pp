import tkinter as tk
from tkinter import messagebox
import parcel_calculator
import mysql.connector
import uuid

class ParcelCalculatorGUI:
    def __init__(self, master):
        self.master = master
        master.title("Parcel Calculator")

        # Create length input label and entry field
        self.length_label = tk.Label(master, text="Length (cm):", fg="blue")
        self.length_label.grid(row=0, column=0)
        self.length_entry = tk.Entry(master)
        self.length_entry.grid(row=0, column=1)

        # Create width input label and entry field
        self.width_label = tk.Label(master, text="Width (cm):", fg="blue")
        self.width_label.grid(row=1, column=0)
        self.width_entry = tk.Entry(master)
        self.width_entry.grid(row=1, column=1)

        # Create height input label and entry field
        self.height_label = tk.Label(master, text="Height (cm):", fg="blue")
        self.height_label.grid(row=2, column=0)
        self.height_entry = tk.Entry(master)
        self.height_entry.grid(row=2, column=1)

        # Create weight input label and entry field
        self.weight_label = tk.Label(master, text="Weight (kg):", fg="blue")
        self.weight_label.grid(row=3, column=0)
        self.weight_entry = tk.Entry(master)
        self.weight_entry.grid(row=3, column=1)

        # Create calculate button
        self.calculate_button = tk.Button(master, text="Calculate", command=self.calculate_price, bg="lightgreen")
        self.calculate_button.grid(row=4, column=0, columnspan=2)

        # Create reset button
        self.reset_button = tk.Button(master, text="Reset", command=self.reset_fields, bg="lightcoral")
        self.reset_button.grid(row=5, column=0, columnspan=2)

        # Create price label
        self.price_label = tk.Label(master, text="", fg="red")
        self.price_label.grid(row=6, column=0, columnspan=2)

    def calculate_price(self):
        try:
            # Get parcel dimensions and weight from entry fields
            length = float(self.length_entry.get())
            width = float(self.width_entry.get())
            height = float(self.height_entry.get())
            weight = float(self.weight_entry.get())
            
            # Calculate parcel price using imported function
            price = parcel_calculator.calculate_price(length, width, height, weight)

            # Update price label with calculated price
            self.price_label.config(text="The price of your parcel is: $" + str(price))

            # Save parcel data to database
            volume = length * width * height
            item_id = str(uuid.uuid4())[:10]
            self.save_to_database(item_id, height, width, length, volume, price)

            # Show a message box to confirm successful calculation
            messagebox.showinfo("Success", "Price calculated and data saved successfully!")

        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for all fields.")

    def save_to_database(self, item_id, height, width, length, volume, price):
        try:
            connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="LelemoveSystem"
            )
            cursor = connection.cursor()
            cursor.execute("INSERT INTO parcels (Item_id, Item_height, Item_width, Item_length, Item_volume, Item_price) VALUES (%s, %s, %s, %s, %s, %s)", 
                           (item_id, height, width, length, volume, price))
            connection.commit()
            cursor.close()
            connection.close()
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def reset_fields(self):
        self.length_entry.delete(0, tk.END)
        self.width_entry.delete(0, tk.END)
        self.height_entry.delete(0, tk.END)
        self.weight_entry.delete(0, tk.END)
        self.price_label.config(text="")

if __name__ == "__main__":
    root = tk.Tk()
    parcel_calculator_gui = ParcelCalculatorGUI(root)
    root.mainloop()
