
from parcel_calculator import calculate_price

def main():
    # Get user input for parcel dimensions and weight
    length = float(input("Enter parcel length in centimeters: "))
    width = float(input("Enter parcel width in centimeters: "))
    height = float(input("Enter parcel height in centimeters: "))
    weight = float(input("Enter parcel weight in kilograms: "))

    # Calculate parcel price using imported function
    price = calculate_price(length, width, height, weight)

    # Save parcel dimensions and weight to a text file
    with open("parcel_data.txt", "a") as file:
        file.write(f"Length: {length}, Width: {width}, Height: {height}, Weight: {weight}, Price: {price}\n")

    # Print parcel price to user
    print("The price of your parcel is: RM", price)

if __name__ == "__main__":
    main()
