import connection as conn
import sys

db = conn.connectionDB()

def check_eligibility(salary):
    if salary > 8000:
        return 1.0
    elif 5000 <= salary <= 8000:
        return 0.7
    elif 3000 <= salary <= 5000:
        return 0.5
    else:
        return 0.3

def insert(name, icnumber, salary):
    amount = 100000  # Maximum loan amount
    rate = check_eligibility(salary)
    loan_eligibility = amount * rate
    loanStatus = "Eligible" if loan_eligibility > 0 else "Not Eligible"

    # Print the results to the terminal
    print(f"Name: {name}")
    print(f"IC Number: {icnumber}")
    print(f"Salary: RM{salary:.2f}")
    print(f"Eligible Loan Amount: RM{loan_eligibility:.2f}")
    print(f"Loan Status: {loanStatus}")

    user_input = input(f"Eligible Loan Amount: RM{loan_eligibility:.2f}. Do you want to proceed? (yes/no): ")
    if user_input.lower() == 'yes':
        try:
            db.cursorObj.execute(
                'INSERT INTO listloan (icnumber, name, salary, amount, loanStatus) VALUES (%s, %s, %s, %s, %s)',
                (icnumber, name, salary, loan_eligibility, loanStatus)
            )
            db.mydb.commit()
            print("Record inserted successfully.")
        except Exception as e:
            print(e)
            db.mydb.rollback()
            print("Error: Record not inserted.")
    else:
        print("Record not inserted.")

def main():
    try:
        name = input("Enter your name: ")
        icnumber = input("Enter your IC number: ")
        salary = float(input("Enter your salary: "))

        insert(name, icnumber, salary)
    except ValueError:
        print("Please enter a valid salary.")
        sys.exit(1)

if __name__ == "__main__":
    main()
