import mysql.connector

class connectionDB:
    def __init__(self):
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="loan"
        )
        self.cursorObj = self.mydb.cursor()
