from tkinter import *
from PIL import ImageTk
from tkinter import ttk
from tkinter import messagebox,filedialog
import connection as con
from tkcalendar import DateEntry
import time
import ttkthemes
import openpyxl

cur = con.mydb.cursor()

# button funtion to exit the form
def exit():
    result=messagebox.askyesno('Confirm','Do you want exit?')
    if result:
        student.destroy()
    else:
        pass

#button funtion to generate the report       
def generate():
    # Ask user to select a file to save the data in
    filename = filedialog.asksaveasfilename(defaultextension='.xlsx')

    # Get all data from the table in a list
    indexing = studentTable.get_children()
    data_list = []
    for index in indexing:
        content = studentTable.item(index)
        datalist = content['values']
        data_list.append(datalist)

    # Create a new Excel workbook and select the active worksheet
    workbook = openpyxl.Workbook()
    worksheet = workbook.active

    column_names = ['ID', 'Name', 'Phone Number',"Email","Address","Gender","DOB","Date Registered","Current Date"]
    worksheet.append(column_names)

    # Write the data to the worksheet
    for row in data_list:
        worksheet.append(row)

    # Save the workbook to the selected file
    workbook.save(filename)

#Funtion that have form.Used for Search,Insert,Update
def form(title,button_text,command):
    global idEntry,NameEntry,phnEntry,mailEntry,addEntry,gender_var,dob,form_input
    form_input = Toplevel()
    form_input.grab_set()
    form_input.title(title)
    form_input.resizable(False, False)

    idLbl = Label(form_input,text="ID:")
    idLbl.grid(row=0,column=0,padx=20,pady=20,stick=W)
    idEntry = Entry(form_input)
    idEntry.grid(row=0,column=1,pady=15,padx=10)

    nameLbl = Label(form_input,text="NAME:")
    nameLbl.grid(row=1,column=0,padx=20,pady=20,stick=W)
    NameEntry = Entry(form_input)
    NameEntry.grid(row=1,column=1,pady=15,padx=10)

    phnLbl = Label(form_input,text="CONTACT NUMBER:")
    phnLbl.grid(row=2,column=0,padx=20,pady=20,stick=W)
    phnEntry = Entry(form_input)
    phnEntry.grid(row=2,column=1,pady=15,padx=10)

    mailLbl = Label(form_input,text="EMAIL:")
    mailLbl.grid(row=3,column=0,padx=20,pady=20,stick=W)
    mailEntry = Entry(form_input)
    mailEntry.grid(row=3,column=1,pady=15,padx=10)

    addLbl = Label(form_input,text="ADDRESS:")
    addLbl.grid(row=4,column=0,padx=20,pady=20,stick=W)
    addEntry = Entry(form_input)
    addEntry.grid(row=4,column=1,pady=15,padx=10)

    # create a StringVar to store the selected gender
    gender_var = StringVar(value="Male")

    # create the "Gender" label
    genLbl = Label(form_input, text="GENDER:")
    genLbl.grid(row =5, column=0, stick=W)

    # create the radio buttons for gender
    male_radio = Radiobutton(form_input, text="Male", variable=gender_var, value="Male")
    male_radio.grid(row=5, column=1, stick=W)

    female_radio = Radiobutton(form_input, text="Female", variable=gender_var, value="Female")
    female_radio.grid(row=5, column=2, stick=W)

    dobLbl = Label(form_input,text="D.O.B:")
    dobLbl.grid(row=6,column=0,padx=20,pady=20,stick=W)

    # create the DateEntry widget for the dobEntry field
    dob = DateEntry(form_input, width=12, background='darkblue',foreground='white', borderwidth=2)
    dob.grid(row=6,column=1,pady=15,padx=10,stick=W)

    dob.config(date_pattern='yyyy-mm-dd')

    inputBtn=ttk.Button(form_input,text=button_text,command=command)
    inputBtn.grid(row=8,columnspan=2)
     #To make sure to get value on the entry when user choose update button
    if title == 'Form Update':

        indexing=studentTable.focus()
        content=studentTable.item(indexing)
        listdata=content['values']
        idEntry.insert(0,listdata[0])
        NameEntry.insert(0,listdata[1])
        phnEntry.insert(0,listdata[2])
        mailEntry.insert(0,listdata[3])
        addEntry.insert(0,listdata[4])
        gender_var.set(listdata[5])
        dob.set_date(listdata[6])

#funtion and query to update
def update_student():
    idStu = idEntry.get()
    nameStu = NameEntry.get()
    phnStu = phnEntry.get()
    mailStu = mailEntry.get()
    addStu = addEntry.get()
    genStu = gender_var.get()
    dobStu = dob.get()
    date = time.strftime('%d/%m/%Y')
    cTime = time.strftime('%H:%M:%S')
    sql = 'UPDATE student SET Student_Name=%s, Phone_Num=%s, Email=%s, Address=%s, Gender=%s, DOB=%s, Reg_Date=%s, Reg_Time=%s WHERE Student_ID=%s'
    var = (nameStu, phnStu, mailStu, addStu, genStu, dobStu, date, cTime, idStu)
    cur.execute(sql,var)
    con.mydb.commit()
    messagebox.showinfo('Success',f'ID {idStu} is updated successfully.')
    form_input.destroy()
    # Clear the contents of the treeview widget
    for row in studentTable.get_children():
        studentTable.delete(row)
    # Fetch the updated data from the database and populate the treeview widget
    cur.execute("SELECT * FROM student")
    rows = cur.fetchall()
    for row in rows:
        studentTable.insert("", END, values=row)


#funtion to show data in treeview
def show():
    sql = 'SELECT * FROM student'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    studentTable.delete(*studentTable.get_children())
    for data in fetched_data:
        datalist = list(data)
        studentTable.insert('',END,values=datalist)

#funtion to delete the data
def delete():
    indexing = studentTable.focus()
    if not indexing:
        messagebox.showerror('Error', 'Please select a row to delete')
        raise ValueError('Select a student')
        return
    content = studentTable.item(indexing)
    content_id = content['values'][0]
    sql = 'DELETE FROM student where Student_ID=%s'
    cur.execute(sql,(content_id,))
    con.mydb.commit()
    messagebox.showinfo('Delete',f'This {content_id} is deleted successfully.')
    sql = 'SELECT * FROM student'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    studentTable.delete(*studentTable.get_children())
    for data in fetched_data:
        studentTable.insert('',END,values=data)

#Function to search
def search_student():

    idStu = idEntry.get()
    nameStu = NameEntry.get()
    phnStu = phnEntry.get()
    mailStu = mailEntry.get()
    addStu = addEntry.get()
    genStu = gender_var.get()
    dobStu = dob.get()
    date = time.strftime('%d/%m/%Y')
    cTime = time.strftime('%H:%M:%S')
    sql = "SELECT * FROM student WHERE Student_ID=%s or Student_Name=%s or Phone_Num=%s or Email=%s or Address=%s or Gender=%s or DOB=%s"
    var = (idStu, nameStu, phnStu, mailStu, addStu, genStu, dobStu)
    try:
        cur.execute(sql,var)
        con.mydb.commit()
    except:
        con.mydb.rollback()
    messagebox.showinfo('Success', 'Data searched successfully!!!', parent=form_input)
    sql = 'SELECT * FROM student WHERE Student_ID=%s or Student_Name=%s'  
    cur.execute(sql, (idEntry.get(), NameEntry.get()))
    fetched_data = cur.fetchall()
    studentTable.delete(*studentTable.get_children())
    for data in fetched_data:
        studentTable.insert('', END, values=data)

#funtion to insert new data
def insert_student():
    idStu = idEntry.get()
    nameStu = NameEntry.get()
    phnStu = phnEntry.get()
    mailStu = mailEntry.get()
    addStu = addEntry.get()
    genStu = gender_var.get()
    dobStu = dob.get()
    
    # Check if all fields are filled
    if not all([idStu, nameStu, phnStu, mailStu, addStu, genStu, dobStu]):
        messagebox.showerror('Error', 'Please fill in all fields', parent=form_input)
        raise ValueError('Insert all data')
        return
    
    sql = "INSERT INTO student (Student_ID, Student_Name, Phone_Num, Email, Address, Gender, DOB, Reg_Date, Reg_Time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    var = (idStu, nameStu, phnStu, mailStu, addStu, genStu, dobStu, date, cTime)
    try:
        cur.execute(sql,var)
        con.mydb.commit()
    except:
        con.mydb.rollback()
    
    messagebox.showinfo('Success', 'Data added successfully!!!', parent=form_input)
    
    # Update table
    sql = 'SELECT * FROM student'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    studentTable.delete(*studentTable.get_children())
    for data in fetched_data:
        datalist = list(data)
        studentTable.insert('',END,values=datalist)


#Funtion to show real time and date
def clock():
    global date,cTime
    date=time.strftime('%d/%m/%Y')
    cTime=time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f'    Date: {date}\nTime:{cTime}')
    datetimeLabel.after(1000,clock)

# To set the theme,size of window,set false resizable window
student=ttkthemes.ThemedTk()
student.get_themes()
student.set_theme('winxpblue')
student.geometry("1366x700+0+0")
student.resizable(False,False)

#set the time and date
datetimeLabel=Label(student,font=('arial',15,'bold'))
datetimeLabel.place(x=5,y=5)
clock()

#Title
tLabel=Label(student,text="Sistem Pengurusan Sekolah",font=('arial',20,'bold'))
tLabel.place(x=550,y=0)

btnFrame = Frame(student)
btnFrame.place(x=50,y=80,width=300,height=650)

student_logo=PhotoImage(file='C:/Users/wan idham/CODING/img/student.png')
student_label=Label(btnFrame,image=student_logo)
student_label.grid(row=0,column=0)

#buttons for handle database
addBtn = ttk.Button(btnFrame,text='Add Student',command=lambda:form("Form Insert","INSERT",insert_student))
addBtn.grid(row=1,column=0,pady=20)

srcBtn = ttk.Button(btnFrame,text='Search Student',command=lambda:form("Form Search","SEARCH",search_student))
srcBtn.grid(row=2,column=0,pady=20)

uptBtn = ttk.Button(btnFrame,text='Update Student',command=lambda:form("Form Update","UPDATE",update_student))
uptBtn.grid(row=3,column=0,pady=20)

delBtn = ttk.Button(btnFrame,text='Delete Student',command=delete)
delBtn.grid(row=4,column=0,pady=20)

shwBtn = ttk.Button(btnFrame,text='Show Student',command=show)
shwBtn.grid(row=5,column=0,pady=20)

extBtn = ttk.Button(btnFrame,text='Exit Pelajar',command=exit)
extBtn.grid(row=7,column=0,pady=20)

#Creating a frame for treeview
tableFrame = Frame(student)
tableFrame.place(x=550,y=80,height=600,width=820)

#Createing scrollbar for treeview
scrollBarX=Scrollbar(tableFrame,orient=HORIZONTAL)
scrollBarY=Scrollbar(tableFrame,orient=HORIZONTAL)

#Creating treeview
studentTable=ttk.Treeview(tableFrame,columns=('ID','Name','Phone','Email','Address','Gender',
    'D.O.B','Date','Time'),xscrollcommand=scrollBarX.set,yscrollcommand=scrollBarY.set)

#adding scroll bar
scrollBarX.config(command=studentTable.xview)
scrollBarY.config(command=studentTable.yview)

#fitting scrollbar
scrollBarX.pack(side=BOTTOM,fill=X)
scrollBarY.pack(side=RIGHT,fill=Y)

#creating attribute
studentTable.pack(fill=BOTH,expand=1)
studentTable.heading('ID',text="ID")
studentTable.heading('Name',text="NAME")
studentTable.heading('Phone',text="Contact Number")
studentTable.heading('Email',text="E-Mail")
studentTable.heading('Address',text="ADDRESS")
studentTable.heading('Gender',text="GENDER")
studentTable.heading('D.O.B',text="DOB")
studentTable.heading('Date',text="ADDED DATE")
studentTable.heading('Time',text="ADDED TIME")


#placing attribute
studentTable.column('ID',width=100,anchor=CENTER)
studentTable.column('Name',width=100,anchor=CENTER)
studentTable.column('Phone',width=100,anchor=CENTER)
studentTable.column('Email',width=130,anchor=CENTER)
studentTable.column('Address',width=100,anchor=CENTER)
studentTable.column('Gender',width=100,anchor=CENTER)
studentTable.column('D.O.B',width=100,anchor=CENTER)
studentTable.column('Date',width=100,anchor=CENTER)
studentTable.column('Time',width=100,anchor=CENTER)

#setting style for treeviev
style=ttk.Style()
style.configure('Treeview',rowheight=40)

studentTable.config(show='headings')

student.mainloop()
