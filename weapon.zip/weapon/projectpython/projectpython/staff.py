from tkinter import *
from PIL import ImageTk
from tkinter import ttk
from tkinter import messagebox,filedialog
import connection as con
from tkcalendar import DateEntry
import time
import ttkthemes
import openpyxl

cur = con.mydb.cursor()

# button funtion to exit the form
def exit():
	result=messagebox.askyesno('Confirm','Do you want exit?')
	if result:
		staff.destroy()
	else:
		pass

#button funtion to generate the report
def generate():
    # Ask user to select a file to save the data in
    filename = filedialog.asksaveasfilename(defaultextension='.xlsx')

    # Get all data from the table in a list
    indexing = staffTable.get_children()
    data_list = []
    for index in indexing:
        content = staffTable.item(index)
        datalist = content['values']
        data_list.append(datalist)

    # Create a new Excel workbook and select the active worksheet
    workbook = openpyxl.Workbook()
    worksheet = workbook.active

    column_names = ['ID', 'Name', 'Phone Number',"Email","Address","Gender","DOB","Date Registered","Current Date","POST"]
    worksheet.append(column_names)

    # Write the data to the worksheet
    for row in data_list:
        worksheet.append(row)

    # Save the workbook to the selected file
    workbook.save(filename)

#Funtion that have form.Used for Search,Insert,Update
def form(title,button_text,command):
    global idEntry,NameEntry,phnEntry,mailEntry,addEntry,gender_var,dob,post_combo,form_input
    form_input = Toplevel()
    form_input.grab_set()
    form_input.title(title)
    form_input.resizable(False, False)

    idLbl = Label(form_input,text="ID:")
    idLbl.grid(row=0,column=0,padx=20,pady=20,stick=W)
    idEntry = Entry(form_input)
    idEntry.grid(row=0,column=1,pady=15,padx=10)

    nameLbl = Label(form_input,text="NAME:")
    nameLbl.grid(row=1,column=0,padx=20,pady=20,stick=W)
    NameEntry = Entry(form_input)
    NameEntry.grid(row=1,column=1,pady=15,padx=10)

    phnLbl = Label(form_input,text="Phone Number:")
    phnLbl.grid(row=2,column=0,padx=20,pady=20,stick=W)
    phnEntry = Entry(form_input)
    phnEntry.grid(row=2,column=1,pady=15,padx=10)

    mailLbl = Label(form_input,text="EMAIL:")
    mailLbl.grid(row=3,column=0,padx=20,pady=20,stick=W)
    mailEntry = Entry(form_input)
    mailEntry.grid(row=3,column=1,pady=15,padx=10)

    addLbl = Label(form_input,text="Alamat:")
    addLbl.grid(row=4,column=0,padx=20,pady=20,stick=W)
    addEntry = Entry(form_input)
    addEntry.grid(row=4,column=1,pady=15,padx=10)

    # create a StringVar to store the selected gender
    gender_var = StringVar(value="Male")

    # create the "Gender" label
    genLbl = Label(form_input, text="Jantina:")
    genLbl.grid(row =5, column=0, stick=W)

    # create the radio buttons for gender
    male_radio = Radiobutton(form_input, text="Lelaki", variable=gender_var, value="Male")
    male_radio.grid(row=5, column=1, stick=W)

    female_radio = Radiobutton(form_input, text="Perempuan", variable=gender_var, value="Female")
    female_radio.grid(row=5, column=2, stick=W)

    dobLbl = Label(form_input,text="D.O.B:")
    dobLbl.grid(row=6,column=0,padx=20,pady=20,stick=W)

    # create the DateEntry widget for the dobEntry field
    dob = DateEntry(form_input, width=12, background='darkblue',foreground='white', borderwidth=2)
    dob.grid(row=6,column=1,pady=15,padx=10,stick=W)

    dob.config(date_pattern='yyyy-mm-dd')

    postLbl = Label(form_input, text="POST/POSITION:")
    postLbl.grid(row=7, column=0, padx=20, pady=20, sticky=W)

    post_options = ['-Select-','Teacher', 'Clerk', 'Accountant', 'Librarian']
    post_combo = ttk.Combobox(form_input, values=post_options)
    post_combo.current(0)  # sets the default value of combobox to '-Select-'
    post_combo.grid(row=7, column=1, pady=15, padx=10, sticky=W)

    inputBtn=ttk.Button(form_input,text=button_text,command=command)
    inputBtn.grid(row=8,columnspan=2)
    #To make sure to get value on the entry when user choose update button
    if title == 'Form Update':

        indexing=staffTable.focus()
        content=staffTable.item(indexing)
        listdata=content['values']
        idEntry.insert(0,listdata[0])
        NameEntry.insert(0,listdata[1])
        phnEntry.insert(0,listdata[2])
        mailEntry.insert(0,listdata[3])
        addEntry.insert(0,listdata[4])
        gender_var.set(listdata[5])
        dob.set_date(listdata[6])
        post_combo.set(listdata[9])

#funtion and query to update
def update_staff():
    idSta = idEntry.get()
    nameSta = NameEntry.get()
    phnSta = phnEntry.get()
    mailSta = mailEntry.get()
    addSta = addEntry.get()
    genSta = gender_var.get()
    dobSta = dob.get()
    date = time.strftime('%d/%m/%Y')
    cTime = time.strftime('%H:%M:%S')
    post = post_combo.get()
    sql = 'UPDATE staff SET Staff_Name=%s, Phone_Num=%s, Email=%s, Address=%s, Gender=%s, DOB=%s, Reg_Date=%s, Reg_Time=%s, Post=%s WHERE Staff_ID=%s'
    var = (nameSta, phnSta, mailSta, addSta, genSta, dobSta, date, cTime, post, idSta)
    cur.execute(sql,var)
    con.mydb.commit()
    messagebox.showinfo('Success',f'ID {idSta} is updated successfully.')
    form_input.destroy()
    # Clear the contents of the treeview widget
    for row in staffTable.get_children():
        staffTable.delete(row)
    # Fetch the updated data from the database and populate the treeview widget
    cur.execute("SELECT * FROM staff")
    rows = cur.fetchall()
    for row in rows:
        staffTable.insert("", END, values=row)


#funtion to show data in treeview
def show():
    sql = 'SELECT * FROM staff'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    staffTable.delete(*staffTable.get_children())
    for data in fetched_data:
        datalist = list(data)
        staffTable.insert('',END,values=datalist)

#funtion to delete the data
def delete():
    indexing=staffTable.focus()
    content=staffTable.item(indexing)
    content_id=content['values'][0]
    sql = 'DELETE FROM staff where Staff_ID=%s'
    cur.execute(sql,(content_id,))
    con.mydb.commit()
    messagebox.showinfo('Delete',f'This {content_id} is deleted successfully.')
    sql = 'SELECT * FROM staff'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    staffTable.delete(*staffTable.get_children())
    for data in fetched_data:
        staffTable.insert('',END,values=data)

#Function to search
def search_staff():

    idSta = idEntry.get()
    nameSta = NameEntry.get()
    phnSta = phnEntry.get()
    mailSta = mailEntry.get()
    addSta = addEntry.get()
    genSta = gender_var.get()
    dobSta = dob.get()
    post = post_combo.get()
    date = time.strftime('%d/%m/%Y')
    cTime = time.strftime('%H:%M:%S')
    sql = "SELECT * FROM staff WHERE Staff_ID=%s or Staff_Name=%s or Phone_Num=%s or Email=%s or Address=%s or Gender=%s or DOB=%s or Post=%s"
    var = (idSta, nameSta, phnSta, mailSta, addSta, genSta, dobSta,post)
    try:
        cur.execute(sql,var)
        con.mydb.commit()
    except:
        con.mydb.rollback()
    messagebox.showinfo('Success', 'Data searched successfully!!!', parent=form_input)
    sql = 'SELECT * FROM staff WHERE Staff_ID=%s or Staff_Name=%s'  # modified SQL statement
    cur.execute(sql, (idEntry.get(), NameEntry.get()))
    fetched_data = cur.fetchall()
    staffTable.delete(*staffTable.get_children())
    for data in fetched_data:
        staffTable.insert('', END, values=data)

#funtion to insert new data
def insert_staff():

    idSta = idEntry.get()
    nameSta = NameEntry.get()
    phnSta = phnEntry.get()
    mailSta = mailEntry.get()
    addSta = addEntry.get()
    genSta = gender_var.get()
    dobSta = dob.get()
    post = post_combo.get()

    # Check if all fields are filled
    if not all([idSta, nameSta, phnSta, mailSta, addSta, genSta, dobSta,post]):
        messagebox.showerror('Error', 'Please fill in all fields', parent=form_input)
        raise ValueError('Insert all data')
        return

    sql = "INSERT INTO staff (Staff_ID, Staff_Name, Phone_Num, Email, Address, Gender, DOB, Reg_Date, Reg_Time,Post) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s,%s)"
    var = (idSta, nameSta, phnSta, mailSta, addSta, genSta, dobSta, date, cTime,post)
    try:
        cur.execute(sql,var)
        con.mydb.commit()
    except:
        con.mydb.rollback()
    messagebox.showinfo('Success', 'Data added successfully!!!', parent=form_input)

     # Update table
    sql = 'SELECT * FROM staff'
    cur.execute(sql)
    fetched_data=cur.fetchall()
    staffTable.delete(*staffTable.get_children())
    for data in fetched_data:
        datalist = list(data)
        staffTable.insert('',END,values=datalist)

#Funtion to show real time and date
def clock():
    global date,cTime
    date=time.strftime('%d/%m/%Y')
    cTime=time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f'    Date: {date}\nTime:{cTime}')
    datetimeLabel.after(1000,clock)

# To set the theme,size of window,set false resizable window
staff=ttkthemes.ThemedTk()
staff.get_themes()
staff.set_theme('winxpblue')
staff.geometry("1366x700+0+0")
staff.resizable(False,False)

#set the time and date
datetimeLabel=Label(staff,font=('arial',15,'bold'))
datetimeLabel.place(x=5,y=5)
clock()

#Title
tLabel=Label(staff,text="Sistem Pengurusan Sekolah",font=('arial',20,'bold'))
tLabel.place(x=550,y=0)

btnFrame = Frame(staff)
btnFrame.place(x=50,y=80,width=300,height=650)

staff_logo=PhotoImage(file='C:/Users/wan idham/CODING/img/teacher.png')
staff_label=Label(btnFrame,image=staff_logo)
staff_label.grid(row=0,column=0)

#buttons for handle database
addBtn = ttk.Button(btnFrame,text='Add Staff',command=lambda:form("Form Insert","INSERT",insert_staff))
addBtn.grid(row=1,column=0,pady=20)

srcBtn = ttk.Button(btnFrame,text='Search Staff',command=lambda:form("Form Search","SEARCH",search_staff))
srcBtn.grid(row=2,column=0,pady=20)

uptBtn = ttk.Button(btnFrame,text='Update Staff',command=lambda:form("Form Update","UPDATE",update_staff))
uptBtn.grid(row=3,column=0,pady=20)

delBtn = ttk.Button(btnFrame,text='Delete Staff',command=delete)
delBtn.grid(row=4,column=0,pady=20)

shwBtn = ttk.Button(btnFrame,text='Show Staff',command=show)
shwBtn.grid(row=5,column=0,pady=20)

extBtn = ttk.Button(btnFrame,text='Exit Staff',command=exit)
extBtn.grid(row=7,column=0,pady=20)

#Creating a frame for treeview
tableFrame = Frame(staff)
tableFrame.place(x=550,y=80,height=600,width=820)

#Createing scrollbar for treeview
scrollBarX=Scrollbar(tableFrame,orient=HORIZONTAL)
scrollBarY=Scrollbar(tableFrame,orient=HORIZONTAL)

#Creating treeview
staffTable=ttk.Treeview(tableFrame,columns=('ID','Name','Phone','Email','Address','Gender',
	'D.O.B','Date','Time','POST'),xscrollcommand=scrollBarX.set,yscrollcommand=scrollBarY.set)
#adding scroll bar
scrollBarX.config(command=staffTable.xview)
scrollBarY.config(command=staffTable.yview)

#fitting scrollbar
scrollBarX.pack(side=BOTTOM,fill=X)
scrollBarY.pack(side=RIGHT,fill=Y)

#creating attribute
staffTable.pack(fill=BOTH,expand=1)
staffTable.heading('ID',text="ID")
staffTable.heading('Name',text="NAME")
staffTable.heading('Phone',text="Contact Number")
staffTable.heading('Email',text="E-Mail")
staffTable.heading('Address',text="ADDRESS")
staffTable.heading('Gender',text="GENDER")
staffTable.heading('D.O.B',text="DOB")
staffTable.heading('Date',text="ADDED DATE")
staffTable.heading('Time',text="ADDED TIME")
staffTable.heading('POST',text="POST")

#placing attribute
staffTable.column('ID',width=100,anchor=CENTER)
staffTable.column('Name',width=100,anchor=CENTER)
staffTable.column('Phone',width=100,anchor=CENTER)
staffTable.column('Email',width=130,anchor=CENTER)
staffTable.column('Address',width=100,anchor=CENTER)
staffTable.column('Gender',width=100,anchor=CENTER)
staffTable.column('D.O.B',width=100,anchor=CENTER)
staffTable.column('Date',width=100,anchor=CENTER)
staffTable.column('Time',width=100,anchor=CENTER)
staffTable.column('POST',width=100,anchor=CENTER)

#setting style for treeviev
style=ttk.Style()
style.configure('Treeview',rowheight=40)

staffTable.config(show='headings')

staff.mainloop()
