from tkinter import *
from tkinter import messagebox
from PIL import ImageTk
import connection as con  # assuming "connection.py" has been defined
cur = con.mydb.cursor()

class LoginWindow:
    def __init__(self, master):
        """
        Constructor method for LoginWindow class.

        Args:
            master: the parent window.
        """
        self.master = master
        self.master.geometry("500x500")
        self.master.resizable(False, False)
        self.master.title("Sistem Pengurusan Sekolah ")
        
        # Background image
        self.bg = ImageTk.PhotoImage(file="C:/Users/wan idham/CODING/img/background.jpg")
        self.bg_label = Label(self.master, image=self.bg)
        self.bg_label.place(x=0, y=0)

        # Title label
        self.title_label = Label(self.master, text="Admin", font=('times new roman', 20, 'bold'),bg="gray")
        self.title_label.place(x=180, y=50)

        # Login frame
        self.login_frame = Frame(self.master,bg="gray")
        self.login_frame.place(x=100, y=100)

        # Admin logo
        self.admin_logo = PhotoImage(file="C:/Users/wan idham/CODING/img/admin.png")
        self.admin_label = Label(self.login_frame, image=self.admin_logo)
        self.admin_label.grid(row=0, column=0, columnspan=2, pady=10)

        # Username entry and label
        un_image = PhotoImage(file="C:/Users/wan idham/CODING/img/username.png")
        self.u_name_label = Label(self.login_frame, image=un_image, text="Username:",font=('times new roman','15'),bg="gray", compound=LEFT)
        self.u_name_label.grid(row=1, column=0, pady=10, padx=20)
        self.u_name_entry = Entry(self.login_frame)
        self.u_name_entry.grid(row=1, column=1, pady=10, padx=20)

        # Password entry and label
        pw_image = PhotoImage(file="C:/Users/wan idham/CODING/img/lock.png")
        self.pw_label = Label(self.login_frame, image=pw_image, text="Password:",font=('times new roman','15'),bg="gray", compound=LEFT)
        self.pw_label.grid(row=2, column=0, pady=10, padx=20)
        self.pw_entry = Entry(self.login_frame, show="*")
        self.pw_entry.grid(row=2, column=1, pady=10, padx=20)

        # Login button
        self.login_button = Button(self.login_frame, text="Log Masuk", font=('times new roman', 15, 'bold'), command=self.login)
        self.login_button.grid(row=3, column=1)
        
    def login(self):
        # Get the username and password entered by the user
        username = self.u_name_entry.get()
        password = self.pw_entry.get()

        # Check if username or password fields are empty
        if not username:
            messagebox.showerror('Error', 'Sila masukkan username')
        elif not password:
            messagebox.showerror('Error', 'Sila masukkan password')
        else:
            # Check if the entered username and password are correct
            query = "SELECT password FROM admin WHERE username = %s"
            var = (username,)
            cur.execute(query, var)
            result = cur.fetchone()
            if result:
                db_password = result[0]
                if password == db_password:
                    messagebox.showinfo('Success', 'Selamat Datang')
                    # Close the current window and open the main menu window
                    self.master.destroy()
                    import mainmenu
                else:
                    messagebox.showerror('Error', 'Kata laluan salah. Sila cuba lagi')
            else:
                messagebox.showerror('Error', 'Username tidak ditemui.')




if __name__ == "__main__":
    # Create the main window and LoginWindow instance
    window = Tk()
    LoginWindow(window)
    window.mainloop()
