import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
 
)
print("...Successful connection to database...")

mycursor = mydb.cursor()
mycursor.execute("CREATE DATABASE IF NOT EXISTS dbSchool")

mycursor =mydb.cursor()
mycursor.execute("USE dbSchool")

mycursor = mydb.cursor()
admin = """CREATE TABLE IF NOT EXISTS admin(
                password VARCHAR(10) NOT NULL,
                username VARCHAR(20) NOT NULL,
                PRIMARY KEY (password)
                )"""
mycursor.execute(admin) 

student = """CREATE TABLE IF NOT EXISTS student(
                Student_ID VARCHAR(20) NOT NULL,
                Student_Name VARCHAR(50) NOT NULL,
                Phone_Num VARCHAR(20) NOT NULL,
                Email VARCHAR(30) NOT NULL,
                Address VARCHAR(50) NOT NULL,
                Gender VARCHAR(10) NOT NULL,
                DOB VARCHAR(20) NOT NULL,
                Reg_Date VARCHAR(20) NOT NULL,
                Reg_Time VARCHAR(20) NOT NULL,
                PRIMARY KEY (Student_ID)
                )"""
mycursor.execute(student) 

staff = """CREATE TABLE IF NOT EXISTS staff(
                Staff_ID VARCHAR(20) NOT NULL,
                Student_Name VARCHAR(50) NOT NULL,
                Phone_Num VARCHAR(20) NOT NULL,
                Email VARCHAR(30) NOT NULL,
                Address VARCHAR(50) NOT NULL,
                Gender VARCHAR(10) NOT NULL,
                DOB VARCHAR(20) NOT NULL,
                Reg_Date VARCHAR(20) NOT NULL,
                Reg_Time VARCHAR(20) NOT NULL,
                Post VARCHAR(20) NOT NULL,
                PRIMARY KEY (Staff_ID)
                )"""
mycursor.execute(staff) 
