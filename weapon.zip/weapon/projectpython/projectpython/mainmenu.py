from tkinter import *
from PIL import ImageTk

# define a function to open the student window
def student():
    # close the current window
    root.destroy()
    # import the student window
    import Student

# define a function to open the staff window
def staff():
    # close the current window
    root.destroy()
    # import the staff window
    import staff

# create the root window
root=Tk()

# set the size, title, and disable resizing of the window
root.geometry("300x300")
root.title("Menu Utama")
root.resizable(False,False)

# load the background image
bg=ImageTk.PhotoImage(file="C:/Users/wan idham/CODING/img/background.jpg")

# create a label to display the background image
bgLabel=Label(root,image=bg)
bgLabel.place(x=0,y=0)

# create a frame to hold the buttons
selectionFrame=Frame(root,bg='gray')
selectionFrame.place(x=100,y=50)

# create a label to prompt the user to select an option
selectionLabel=Label(selectionFrame,text="Pilih Salah Satu",font=('times new roman','15'),bg="gray")
selectionLabel.grid(row=0,column=0,pady=10)

# create a button to open the staff window
staffButton=Button(selectionFrame,text="Staff",font=('times new roman',15,'bold'),command=staff)
staffButton.grid(row=1,column=0,pady=10)

# create a button to open the student window
studentButton=Button(selectionFrame,text="Pelajar",font=('times new roman',15,'bold'),command=student)
studentButton.grid(row=2,column=0,pady=10)

# start the main event loop
root.mainloop()
