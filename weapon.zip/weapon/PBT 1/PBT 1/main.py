import os
import utils

def register():
    # Function to register graduates into the system
    name = input("Enter your name: ")
    matric_number = input("Enter your matric number: ")
    department = input("Enter your department: ")
    gender = input("Enter your gender: ")
    telephone_number = input("Enter your telephone number: ")
    email = input("Enter your email: ")
    
    # Write graduate data to a file
    utils.write_data("graduate_data.txt", f"{name},{matric_number},{department},{gender},{telephone_number},{email}\n")
    print("Registration successful!")

def vote_themes():
    # Function to allow graduates to vote for themes
    themes = ["Theme 1", "Theme 2", "Theme 3"]  # Example themes
    print("Propose themes for convocation ceremony:")
    for i, theme in enumerate(themes, 1):
        print(f"{i}. {theme}")
    
    for _ in range(2):  # Each graduate can vote for two themes
        vote = int(input("Enter the number of the theme you want to vote for: "))
        filename = f"theme{vote}.txt"
        print("Voting for theme:", filename)  # Debugging
        utils.increment_vote(filename)
    
    print("Voting successful!")

def main():
    # Create vote count files with initial vote counts
    utils.create_vote_files()
    
    while True:
        print("\nWelcome to PP University Convocation Voting System")
        print("1. Register")
        print("2. Vote for Themes")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            register()
        elif choice == "2":
            vote_themes()
        elif choice == "3":
            print("Thank you for using PP University Convocation Voting System")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
1
