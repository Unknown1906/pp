
import os

def create_vote_files():
    # Function to create vote count files for themes if they don't exist
    for i in range(1, 4):
        filename = f"theme{i}.txt"
        if not os.path.exists(filename):
            try:
                with open(filename, "w") as file:
                    file.write("0")  # Set initial vote count to 0
            except Exception as e:
                print(f"Error creating file {filename}: {e}")
        else:
            print("File already exists")

def write_data(filename, data):
    # Function to write data to a text file
    try:
        with open(filename, "a") as file:
            file.write(data)
    except Exception as e:
        print(f"Error writing data to {filename}: {e}")

def increment_vote(filename):
    # Function to increment the vote count for a theme
    try:
        with open(filename, "r+") as file:
            count = int(file.read() or 0)
            file.seek(0)
            file.write(str(count + 1))
    except Exception as e:
        print(f"Error incrementing vote count in {filename}: {e}")

