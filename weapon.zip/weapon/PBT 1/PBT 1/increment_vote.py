import os

def increment_vote(filename):
    # Function to increment the vote count for a theme
    try:
        filepath = os.path.join(os.path.dirname(__file__), filename)  # Get absolute file path
        with open(filepath, "r+") as file:
            count_str = file.read().strip()  # Read and remove leading/trailing whitespace
            if count_str:  # Check if count_str is not empty
                count = int(count_str)
                file.seek(0)
                file.write(str(count + 1))
            else:
                print(f"No vote count found in {filename}")
    except FileNotFoundError:
        print(f"File {filename} not found.")
    except ValueError:
        print(f"Error: Invalid vote count in {filename}.")
    except Exception as e:
        print(f"Error incrementing vote count in {filename}: {e}")
