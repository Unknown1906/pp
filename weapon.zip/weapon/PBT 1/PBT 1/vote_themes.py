
def vote_themes():
    # Function to allow graduates to vote for themes
    themes = ["Theme 1", "Theme 2", "Theme 3"]  # Example themes
    print("Propose themes for convocation ceremony:")
    for i, theme in enumerate(themes, 1):
        print(f"{i}. {theme}")

    try:
        for _ in range(2):  # Each graduate can vote for two themes
            vote = int(input("Enter the number of the theme you want to vote for: "))
            if vote not in range(1, 4):
                raise ValueError("Invalid theme number.")
            filename = f"theme{vote}.txt"
            print("Voting for theme:", filename)  # Debugging
            utils.increment_vote(filename)
        
        print("Voting successful!")
    except ValueError as ve:
        print(ve)
